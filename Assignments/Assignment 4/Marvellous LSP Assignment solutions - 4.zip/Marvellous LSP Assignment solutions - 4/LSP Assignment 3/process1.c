#include<stdio.h>
#include<unistd.h>

int main()
{
int status;
pid_t pid;

	printf("Inside process 1\n");
	if(fork() == 0)
	{
		execl("./executable2","NULL",NULL);
	}
	if(fork() == 0)
	{
		execl("./executable3","NULL",NULL);
	}
	if(fork() == 0)
	{
		execl("./executable4","NULL",NULL);
	}
	return 0;
}

