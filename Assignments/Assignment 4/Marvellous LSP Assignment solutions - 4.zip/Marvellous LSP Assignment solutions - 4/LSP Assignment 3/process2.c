#include<stdio.h>
#include<unistd.h>

int main()
{

		printf("Inside Process 2\n");

	return 0;
}

