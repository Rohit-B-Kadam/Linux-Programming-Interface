#include<stdio.h>
#include<unistd.h>

int main()
{
		printf("Inside Process 4\n");

	return 0;
}

