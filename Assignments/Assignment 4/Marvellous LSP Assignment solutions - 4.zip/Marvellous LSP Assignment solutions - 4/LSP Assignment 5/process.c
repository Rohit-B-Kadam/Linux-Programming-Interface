#include<stdio.h>
#include<unistd.h>

int main()
{
	printf("Parent : Process running\n");

	if(fork() == 0)
	{
		execl("./zombie","NULL",NULL);
	}
	return 0;
}
