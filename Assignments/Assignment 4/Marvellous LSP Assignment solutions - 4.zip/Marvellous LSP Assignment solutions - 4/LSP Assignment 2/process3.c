#include<stdio.h>
#include<unistd.h>

int main()
{
		printf("Inside Process 3\n");

	return 0;
}

