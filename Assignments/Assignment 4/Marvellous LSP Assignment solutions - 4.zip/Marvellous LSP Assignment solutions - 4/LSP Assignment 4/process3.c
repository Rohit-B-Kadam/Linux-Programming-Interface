#include<stdio.h>
#include<unistd.h>

int main()
{
		printf("Inside Process 3\n");
		sleep(5);

	return 0;
}

