
#include <fcntl.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
	int fd, ret = 0,CapCnt = 0;
	int offset;
	char buff[256],data[100];
	
	// If file is opened in read mode we can read the contents from 0 byte 		offset
	fd = open("demo.txt",O_RDONLY);
	if(fd == -1)
	{
		printf("Unable to open file \n");
		return -1;
	}

	while((ret = read(fd,buff,256)) != 0)
	{
		while(ret!=0)
		{
			if(buff[ret] >='A' && buff[ret] <= 'Z')
				CapCnt++;
			ret--;
		}
	}

	close(fd);

	fd = open("count.txt",O_WRONLY | O_APPEND);
	if(fd == -1)
	{
		printf("Unable to open count.txt file");
	}
	sprintf(data,"demo.txt : %d",CapCnt);
	write(fd,data,strlen(data));	
	close(fd);
	return 0;
}
