#include<stdio.h>
#include<unistd.h>

int main()
{
	printf("Parent : Process running\n");

	if(fork() == 0)
	{
		execl("./executable1","NULL",NULL);
	}
	if(fork() == 0)
	{
		execl("./executable2","NULL",NULL);
	}
	return 0;
}
