#include<pthread.h>
#include<stdio.h>

// Function to be considered as a thread
void *ThreadProc2(void *p)
{
	int i = 0;
	printf("Inside thread 2\n");
	for(i = 1000; i>=1;i--)
	{
		printf("Thread2 : %d\n",i);
	}
	pthread_exit(NULL);
}

// Function to be considered as a thread
void *ThreadProc1(void *p)
{
	int i = 0;
	printf("Inside thread 1\n");
	for(i = 1;i<=1000;i++)
	{
		printf("Thread1 : %d\n",i);
	}
	pthread_exit(NULL);
}

int main()
{
	pthread_t thread1,thread2;
	int ret1, ret2 ;

	ret1 = pthread_create(	&thread1,	// Address of pthread_t structure
						NULL,	 	// thread attributes 
						ThreadProc1,	// Function name
						NULL);		// Function parameters
	if(ret1 != 0)
	{
		printf("problem in thread1 creation\n");
	}

	ret2 = pthread_create(	&thread2,	// Address of pthread_t structure
						NULL,	 	// thread attributes 
						ThreadProc2,	// Function name
						NULL);		// Function parameters
	if(ret2 != 0)
	{
		printf("problem in thread2 creation\n");
	}
	
	// It suspen execution of calling thread till target thread terminates
	pthread_join(	thread1,		// thread id
				NULL);		// Location of thread	
	// It suspen execution of calling thread till target thread terminates
	pthread_join(	thread2,		// thread id
				NULL);		// Location of thread	
	
	pthread_exit(NULL); 	// Terminate running thread
	return 0;
}
