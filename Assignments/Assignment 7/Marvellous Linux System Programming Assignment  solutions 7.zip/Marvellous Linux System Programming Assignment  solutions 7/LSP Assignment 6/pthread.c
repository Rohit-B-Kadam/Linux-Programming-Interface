#include<pthread.h>
#include<stdio.h>

// Function to be considered as a thread
void *ThreadProc(void *p)
{
	printf("Inside thread with id %d and data %d\n",pthread_self(),(int)p);
	pthread_exit(NULL);
}

int main()
{
	pthread_t thread[4];
	int ret;
	int i = 0;

	for(i = 0;i<4;i++)
	{
		ret = pthread_create(	&thread[i],	 								NULL,	 	
							ThreadProc,	// Function name
							(void *)i);
		if(ret != 0)
		{
			printf("problem in thread creation\n");
		}

	}
	
	for(i = 0;i<4;i++)
	{
		pthread_join(	thread[i],		// thread id
				NULL);		// Location of thread	
	}	

	pthread_exit(NULL); 	// Terminate running thread
	return 0;
}
