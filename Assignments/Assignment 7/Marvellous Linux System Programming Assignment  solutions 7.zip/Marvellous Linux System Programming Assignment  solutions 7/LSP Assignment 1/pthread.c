#include<pthread.h>
#include<stdio.h>

// Function to be considered as a thread
void *ThreadProc(void *p)
{
	printf("Inside thread\n");

	pthread_exit(NULL);
}

int main()
{
	pthread_t thread1;
	int ret ;
	printf("Inside main thread\n");
	ret = pthread_create(	&thread1,	// Address of pthread_t structure
						NULL,	 	// thread attributes 
						ThreadProc,	// Function name
						NULL);		// Function parameters
	if(ret != 0)
	{
		printf("problem in thread creation\n");
	}
	
	// It suspend execution of calling thread till target thread terminates
	pthread_join(	thread1,		// thread id
				NULL);		// Location of thread	
	
	pthread_exit(NULL); 	// Terminate running thread
	return 0;
}
