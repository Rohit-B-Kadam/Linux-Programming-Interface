/*
Write a program which accept file name which contains data of all file. We have to print  all file names whose size is greater that 10 bytes.
*/

#include <sys/types.h>
#include <dirent.h>
#include <stdio.h>
#include <sys/stat.h>
#include<string.h>
#include<fcntl.h>
#include<stdlib.h>
#include<errno.h>

int main(int argc, char *argv[]) 
{
	DIR *dir;
	struct dirent *entry;
	struct stat filestat;
	char name[100] = {'\0'};
	int fd,ret;
	// Structure which maintain information of file
	typedef struct
	{
		char name[50];
		int size;
	}FILEINFO;

	FILEINFO obj;

	if(argc!= 2)
	{
		printf("Error: Not sufficient arguments\n");
		return -1;
	}

	fd = open(argv[1],O_RDONLY);
	if(fd == -1)
	{
		printf("Unable to open file\n");
		return -1;
	}

	// Read the contents of that file which contains all files data
	while ((ret = read(fd,&obj,sizeof(obj)))!=0)
	{
		// Print file name if its size if greater than 10 bytes
		if(obj.size > 10)
		{
			printf("%s\n",obj.name);
		}

		// skip the contents of file
		lseek(fd,obj.size,SEEK_CUR);
	}

	close(fd);
	return 0;
}
