/*
	Write a program which accept file name and position from user and 	read 20 bytes from that position.
*/

#include <fcntl.h>
#include<stdio.h>
#include<stdlib.h>

int main(int argc, char *argv[])
{
	int fd;
	int ret;
	char buff[50];
	
	if(argc != 3)
	{
		printf("Error: Not sufficient arguments\n");
		return -1;
	}

	// If file is opened in read mode we can read the contents from 0 byte 		offset
	fd = open(argv[1],O_RDONLY);
	if(fd == -1)
	{
		printf("Unable to open file \n");
		return -1;
	}
	// File is opened in read or write mode current file offset
	// is always zero
	// Means we open a file which is already existing and we write 	something
	// in that file then data gets overwritten
	
	// To change the current file offset we can use lseek function	

	lseek(fd,atoi(argv[2]),SEEK_SET);
	// SEEK_SET means staring offset of file
	// SEEK_CUR means current offset of file
	// SEEK_END means last byte offset of file

	read(fd,buff,20);
	
	printf("%s",buff);
	
	close(fd);
	return 0;
}
