/*
	Write a program which accept directory name from user and create
	new directory of that name.
*/

#include <sys/types.h>
#include <sys/stat.h>
#include<stdio.h>

int main(int argc, char *argv[])
{
	int ret;
	
	if(argc != 2)
	{
		printf("Error: Not sufficient argument\n");
		return -1;
	}

	//In this case directory named as NewDirectory is created, 
	// with read/write/search permissions for owner and group, and 
	// with read/search permissions for others.

	// mkdir() system call accept two parameters first as name of the directory
	// and second is permissions for that new directory

	ret = mkdir(argv[1], S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);

	if(ret == -1)
	{
		printf("Unable to create directory\n");
		return -1;
	}

	return 0;
}
