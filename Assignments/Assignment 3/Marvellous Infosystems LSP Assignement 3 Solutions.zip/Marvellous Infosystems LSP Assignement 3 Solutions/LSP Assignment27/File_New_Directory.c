/*
Write a aprogram which accept directory name and file name from user and create file in that directory.
*/

#include <sys/types.h>
#include <dirent.h>
#include <stdio.h>
#include<string.h>
#include <sys/stat.h>
#include <fcntl.h>

int main(int argc, char *argv[]) 
{
	int fd;
	char name[100] = {'\0'};
	
	if(argc != 3)
	{
		printf("Error: Not sufficeient arguments\n");
		return -1;
	}

	sprintf(name,"%s/%s",argv[1],argv[2]);		

	fd = creat(name,0666);

return 0;
}
