/*
	Write a program which accept two file names and check whether 	contents of that files are equal or not.
*/

#include <fcntl.h>
#include<stdio.h>
#include<stdlib.h>
#include <sys/stat.h>

int main(int argc, char *argv[])
{
	int fd1,fd2;
	int ret,flag = 0,ret1 = 0;
	int offset;
	char buff1[256],buff2[256];
	struct stat fileStat1,fileStat2;
	
	if(argc != 3)
	{
		printf("Error: Not sufficient arguments\n");
		return -1;
	}

	ret = stat(argv[1],&fileStat1);
	if(ret == -1)
	{
		printf("Unable to retrive information of file\n");
		return -1;
	}
	
	// Call function stat to get file size before compairing with its data. 
	ret = stat(argv[2],&fileStat2);
	if(ret == -1)
	{
		printf("Unable to retrive information of file\n");
		return -1;
	}

	if((int)fileStat1.st_size != (int)fileStat2.st_size)
	{
		printf("Contents of file are not equal due to size\n");
		return 0;
	}

	//Open both the files in read mode.
	fd1 = open(argv[1],O_RDONLY);
	if(fd1 == -1)
	{
		printf("Unable to open file \n");
		return -1;
	}

	fd2 = open(argv[2],O_RDONLY);
	if(fd2 == -1)
	{
		printf("Unable to open file \n");
		return -1;
	}

	// Loop which is used to compaire the data of both the files
	while((ret = read(fd1,buff1,256)) != 0)
	{
		ret1 = read(fd2,buff2,ret);
		if(memcmp(buff1,buff2,ret) !=0)
		{
			flag = -1;
			break;
		}
	}

	if(flag == -1 || (ret != 0 || ret1 != 0))
	{
		printf("Contents are not equal\n");
	}
	else
	{
		printf("Contents of both the files are equal\n");
	}

	close(fd1);
	close(fd2);

	return 0;
}
