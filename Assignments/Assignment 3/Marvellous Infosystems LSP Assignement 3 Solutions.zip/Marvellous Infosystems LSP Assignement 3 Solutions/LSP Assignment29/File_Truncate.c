/*
	Write a program which accept file name from user and offset, remove all the data from that offset.
*/


#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>

int main(int argc, char *argv[])
{
int ret;
int fd;

if(argc != 3)
{
	printf("Not sufficient arguments\n");
	return -1;
}

// By using this function we can truncate the file after file offset 10		
ret = truncate(argv[1],atoi(argv[2]));
if(ret == -1)
{
	printf("Unable to truncate file\n");
}

return 0;
}
