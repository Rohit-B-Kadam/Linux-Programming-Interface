/*
Write a program which accept directory name from user and create hole in file if size is less than 1kb & if it is greater than 1kb then truncate the remaining data. 
*/

#include <sys/types.h>
#include <dirent.h>
#include <stdio.h>
#include <sys/stat.h>
#include<string.h>
#include<fcntl.h>

int main(int argc, char *argv[]) 
{
	DIR *dir;
	struct dirent *entry;
	struct stat filestat;
	char name[100] = {'\0'};
	int fd,ret;
	char buff[ ] = {' '};

	if(argc!= 2)
	{
		printf("Error: Not sufficient arguments\n");
		return -1;
	}

	// Open the directory
	if ((dir = opendir(argv[1])) == NULL)
	{
		printf("Unable to open specified directory\n");
		return -1;
	}

	while ((entry = readdir(dir)) != NULL)
	{
		// Createaa absolute path
		sprintf(name,"%s/%s", argv[1],entry->d_name);
		stat(name,&filestat);

		// Check file type			
		if(S_ISREG(filestat.st_mode))
		{
			fd = open(name,O_WRONLY);
			if(fd == -1)
			{
				printf("Unable to open file\n");

			}
			if(filestat.st_size < 1024)
			{
				printf("less");
				ret = lseek(fd,1024-filestat.st_size,SEEK_END);
				if(ret == -1)
				{
					printf("lseek fail");
				}				
				ret = write(fd,buff,1);
				close(fd);
			}
			else
			{
				ret = ftruncate(fd,1024);
				close(fd);
			}
		}	
	}

	// closedir() close the directory which is opened by opendir()
	closedir(dir);
	
	return 0;
}
