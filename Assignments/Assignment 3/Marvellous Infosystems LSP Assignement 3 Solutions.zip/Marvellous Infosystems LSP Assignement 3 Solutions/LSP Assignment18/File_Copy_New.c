/*
	Write a program which accept directory name from user and copy first 10 bytes of all files from that directory into newly created file.
*/

#include <sys/types.h>
#include <dirent.h>
#include <stdio.h>
#include<string.h>
#include <sys/stat.h>
#include <fcntl.h>

int main(int argc, char *argv[]) 
{
	DIR *dir;
	int fd,fdWrite,ret;
	struct dirent *entry;
	struct stat fileStat;// Structure which stores all information of file.
	
	char FileName[256];
	char name[100] = {'\0'};
	char buff[50] = {'\0'};	

	if(argc != 2)
	{
		printf("Error: Not sufficeient arguments\n");
		return -1;
	}

	// Open the specified directory
	if ((dir = opendir(argv[1])) == NULL)
	{
		printf("Unable to open specified directory\n");
		return -1;
	}
	
	fdWrite = creat("DemoFile",0666);

	// Traverse directorytes from all regula
	while ((entry = readdir(dir)) != NULL)
	{
		// Use to create absolute path of file
		sprintf(name,"%s/%s",argv[1],entry->d_name);		
		stat(name,&fileStat);				
		
		// Check file size only if it is regular file
		if(S_ISREG(fileStat.st_mode))
		{		
			// open the file to read the data
			fd = open(name,O_RDONLY);
			ret = read(fd,buff,10);
			// write the contents into destnation file
			write(fdWrite,buff,ret);
			close(fd);
		}
		memset(&fileStat,0,sizeof(fileStat));
	}
	close(fdWrite);
	
	// close that opened directory
	closedir(dir);
return 0;
}
