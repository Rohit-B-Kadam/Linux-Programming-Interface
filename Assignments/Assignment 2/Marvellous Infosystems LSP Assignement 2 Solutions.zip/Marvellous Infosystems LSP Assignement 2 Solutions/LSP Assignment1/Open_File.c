/*
	write a program which accept file name from user using command line
	and open that specified file.	
*/
// This program demonstate open system call

#include<stdio.h>
#include<fcntl.h>

int main(int argc, char *argv[])
{
	int fd;
	if(argc != 2)
	{
		printf("Error : Not sufficient arguments\n");
		return -1;
	}

	// Opening file in read mode
	// Syntax : int open(char *path_name,mode_of_file);
	//If success then it will return the proper file descriptor else return -1.

	fd = open(argv[1],O_RDONLY);	// absolute path given
	if(fd == -1)
	{
		printf("Unable to open the file\n");
	}
	else
	{
		printf("File is successfully opened with file descriptor %d in read mode \n",fd);
	}
	close(fd);	// closes the opened file

	return 0;

}
