/*
	Write a program which accept directory name from user and print all 		file names with its type.
*/

#include <sys/types.h>
#include <dirent.h>
#include <stdio.h>
#include <sys/stat.h>

int main(int argc, char *argv[]) 
{
	DIR *dir;
	struct dirent *entry;
	struct stat filestat;
	char name[100] = {'\0'};
	
	if(argc!= 2)
	{
		printf("Error: Not sufficient arguments\n");
		return -1;
	}

	// Open the directory
	if ((dir = opendir(argv[1])) == NULL)
	{
		printf("Unable to open specified directory\n");name
		return -1;
	}

	printf("Contents of directory as \n");

	while ((entry = readdir(dir)) != NULL)
	{
		// Create absolute path
		sprintf(name,"%s/%s", argv[1],entry->d_name);
		stat(name,&filestat);

		printf("%30s : ",entry->d_name);
		// Check file type			
		if(S_ISREG(filestat.st_mode))
			printf("Regular file\n");
		else if(S_ISDIR(filestat.st_mode))
			printf("Directory");
		else if(S_ISLNK(filestat.st_mode))
			printf("Link");	
	}
	
	// readdir() system call returns NULL when it reach end of the directory.

	// closedir() close the directory which is opened by opendir()
	closedir(dir);
return 0;
}
