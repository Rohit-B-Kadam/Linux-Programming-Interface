/*
	Write a program which accept file name and number of bytes from user 	and read that number of bytes from file.
*/

#include <fcntl.h>
#include<stdio.h>
#include<stdlib.h>

int main(int argc, char *argv[])
{
	int fd;
	int ret;
	int offset;
	char *buff = NULL;
	
	if(argc != 3)
	{
		printf("Error: Not sufficient arguments\n");
		return -1;
	}

	// If file is opened in read mode we can read the contents from 0 byte 		offset
	fd = open(argv[1],O_RDONLY);
	if(fd == -1)
	{
		printf("Unable to open file \n");
		return -1;
	}

	// We can read the contents from teh file by using read system call
	// which accept first parameter as file descriptor	
	// second parameter is empty buffer
	// Third parameter is number of bytes to read

	// Allocate memory for local buffer
	buff = (char*)malloc(sizeof(char)*atoi(argv[2]));
	if(buff == NULL)
	{
		printf("Eemory allocation fail\n");
		return -1;
	}	
	ret = read(fd,buff,atoi(argv[2]));

	// read system call returns no of bytes successfully read.
	// It returns -1 if it fails to read
	// It returns 0 if it reach end of file whicle reading

	if(ret != atoi(argv[2]))
	{
		printf("Unable to read expected number of bytes\n");
	}

	printf("Contents of file %s are : \n %s\n",argv[1],buff);

	close(fd);
	return 0;
}
