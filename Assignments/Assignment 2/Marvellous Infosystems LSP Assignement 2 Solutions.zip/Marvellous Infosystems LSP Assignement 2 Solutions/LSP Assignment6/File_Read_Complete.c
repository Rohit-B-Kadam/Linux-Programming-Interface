/*
	Write a program which accept file name and read whole contents of 	that file.
*/

#include <fcntl.h>
#include<stdio.h>
#include<stdlib.h>

int main(int argc, char *argv[])
{
	int fd;
	int ret;
	int offset;
	char buff[256];
	
	if(argc != 2)
	{
		printf("Error: Not sufficient arguments\n");
		return -1;
	}

	// If file is opened in read mode we can read the contents from 0 byte 		offset
	fd = open(argv[1],O_RDONLY);
	if(fd == -1)
	{
		printf("Unable to open file \n");
		return -1;
	}

	// We can read the contents from teh file by using read system call
	// which accept first parameter as file descriptor	
	// second parameter is empty buffer
	// Third parameter is number of bytes to read

	// Allocate memory for local buffer

	while(read(fd,buff,256) != 0)
	{
		printf("%s",buff);
	}

	close(fd);
	return 0;
}
