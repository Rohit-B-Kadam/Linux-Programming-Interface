
#include<sys/resource.h>
#include<stdio.h>

int main()
{
	int ret;

	ret = getpriority(PRIO_PROCESS,0);

	printf("Process priority is %d\n",ret);

	return 0;
}

