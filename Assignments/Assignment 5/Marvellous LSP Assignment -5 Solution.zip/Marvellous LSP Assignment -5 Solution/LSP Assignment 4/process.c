#include<stdio.h>
extern char **environ;
int main()
{
	char **env = environ;
	printf("Environment of our process is \n");
	for(;*env!=NULL;++env)
		printf("%s\n\n",*env);
return 0;
}
