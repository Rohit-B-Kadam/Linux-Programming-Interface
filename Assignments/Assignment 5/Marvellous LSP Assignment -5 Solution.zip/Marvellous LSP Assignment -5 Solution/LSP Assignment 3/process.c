#include<stdio.h>
#include<sched.h>

/*
A call to sched_yeild() results in suspention of the currently running process , 
 afterwhich the process schedular selects new process to run by following the normal scheduling way.
*/

int main()
{
	int ret;

	ret = sched_yield();
	if(ret == 0)
	{
		printf("Yeild the processor\n");
	}	
	return 0;
}
