#include<stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>

#define SHMSZ     27

main()
{
    char c;
    int shmid;
    key_t key;
    char *shm, *s;

    /*
     * We'll name our shared memory segment
     * "5678".
     */
    key = 5678;

    /*
     * Create the segment.
     */
    shmid = shmget(key, SHMSZ, IPC_CREAT | 0666);

    /*
     * Now we attach the segment to our data space.
     */
    shm = shmat(shmid, NULL, 0);
    
/*
     * Now put some things into the memory for the
     * other process to read.
     */
    s = shm;	// base address of shared memory

    for (c = 'a'; c <= 'z'; c++)
	{
        	*s = c;
		s++;	
	}
    *s = NULL;

    /*
     * Finally, we wait until the other process 
     * changes the first character of our memory
     * to '*', indicating that it has read what 
     * we put there.
     */
    while (*shm != '*')
        sleep(1);

    exit(0);
}
